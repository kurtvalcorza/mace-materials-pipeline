"""Probes for the Notebook Review Framework v1 review of tutorials/mace_materials_colab.ipynb
(mace-materials-pipeline @ 77e44236e3cd58de877592f0d9a94dea055f0ea5, notebook blob 1044b4aa).

Environment (labelled, NOT a Colab run): Windows 11, CPython 3.12, private uv venv with the notebook's
own PINS (torch 2.14.0+cpu, mace-torch 0.3.16, e3nn 0.4.4, ase 3.29.0, numpy 2.5.3, safetensors 0.8.0,
huggingface-hub 1.32.0), CPU float64. DIMER_NOTEBOOK_CI_PREINSTALLED=1 so the install cell is skipped
(the install/restart behaviour is judged from the recorded Kaggle run, not here). The two Hub files
(README.md, mace-mp-0b2-small.model) are pre-staged from a local copy whose sha256 the notebook itself
verifies; the audit + conversion still run inside the notebook code.

Usage: python run_probes.py <notebook.ipynb> <run_dir> <prestaged_weights_dir> <results.json>
"""
import contextlib
import io
import json
import os
import shutil
import sys
import time
import traceback
import types
from pathlib import Path

NB, RUN, PRE, OUT = (Path(a).resolve() for a in sys.argv[1:5])
results = {"probes": {}}


def save():
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
code = {i: "".join(c["source"]) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"}

RUN.mkdir(parents=True, exist_ok=True)
(RUN / "weights" / "mace-mp-0b2-small").mkdir(parents=True, exist_ok=True)
for name in ("README.md", "mace-mp-0b2-small.model"):
    shutil.copy2(PRE / name, RUN / "weights" / "mace-mp-0b2-small" / name)
os.chdir(RUN)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
ns: dict = {"__name__": "__main__"}


def run_cell(idx, overrides=None, label=None):
    src = code[idx]
    for k, v in (overrides or {}).items():
        lines = src.splitlines()
        hit = [n for n, ln in enumerate(lines) if ln.startswith(f"{k} = ")]
        if not hit:
            raise KeyError(f"field {k} not found in cell {idx}")
        lines[hit[0]] = f"{k} = {v!r}"
        src = "\n".join(lines)
    buf = io.StringIO()
    t0 = time.perf_counter()
    status, err = "ok", None
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(src, f"<cell {idx}>", "exec"), ns)
    except BaseException as exc:  # noqa: BLE001
        status, err = "error", f"{type(exc).__name__}: {str(exc)[:400]}"
        buf.write(traceback.format_exc()[-1200:])
    return {"cell": idx, "label": label, "status": status, "error": err,
            "seconds": round(time.perf_counter() - t0, 1), "stdout_tail": buf.getvalue()[-2500:]}


def floats(d):
    return {k: v for k, v in d.items() if isinstance(v, float)}


# ---- P1: clean default path (all code cells in order) ----
p1 = []
for idx in sorted(code):
    r = run_cell(idx)
    p1.append(r)
    results["probes"]["P1_default_path"] = {"basis": "direct execution, local CPU (not Colab)", "cells": p1}
    save()
    if r["status"] != "ok":
        break
default_ok = all(r["status"] == "ok" for r in p1)
if default_ok:
    results["probes"]["P1_default_path"]["comparison"] = ns["comparison"]
    results["probes"]["P1_default_path"]["reload_parity"] = ns["parity"]
    results["probes"]["P1_default_path"]["outputs"] = sorted(p.as_posix() for p in Path("outputs").rglob("*") if p.is_file())
save()

if default_ok:
    frozen_test = dict(ns["zero_shot_test"])
    first_adapt_epoch0 = ns["adapt_result"]["history"][0].get("val")
    # ---- P2: documented optional experiment, TRAINABLE_BLOCKS = 0, rerun Section 7 -> 8 -> 9 ----
    p2 = [run_cell(19, {"TRAINABLE_BLOCKS": 0}, "Section 7 with TRAINABLE_BLOCKS=0"),
          run_cell(21, None, "Section 8 rerun"),
          run_cell(23, None, "Section 9 rerun")]
    results["probes"]["P2_experiment_trainable_blocks_0"] = {
        "basis": "direct execution, local CPU (not Colab)",
        "instruction_followed": "Interpretation cell: 'set TRAINABLE_BLOCKS = 0 to train the readouts alone'; reran Sections 7, 8, 9 (the notebook gives no rerun instruction)",
        "epoch0_val_first_default_adapt": first_adapt_epoch0,
        "epoch0_val_experiment_adapt": ns["adapt_result"]["history"][0].get("val"),
        "experiment_n_trainable": ns["adapt_result"]["n_trainable"],
        "cells": p2,
    }
    save()

    # ---- P3: BYOD rerun from Section 4 as instructed, upload shimmed with a valid extended-XYZ ----
    payload = Path("outputs/mace_materials_sample_dataset.xyz").read_bytes()
    colab = types.ModuleType("google.colab")
    colab.files = types.SimpleNamespace(upload=lambda: {"my_structures.xyz": payload})
    google = types.ModuleType("google")
    google.colab = colab
    sys.modules["google"], sys.modules["google.colab"] = google, colab
    adapter_before = ns["pipe"].adapter is not None
    p3 = [run_cell(13, {"USE_BYOD": True}, "Section 4 USE_BYOD=True (shimmed upload)"),
          run_cell(15, None, "Section 5 rerun"),
          run_cell(17, None, "Section 6 rerun (prints frozen_foundation_model)")]
    results["probes"]["P3_byod_rerun"] = {
        "basis": "direct execution, local CPU, google.colab.files.upload shimmed with the sample XYZ",
        "pipe_adapter_attached_when_section6_reran": adapter_before,
        "true_frozen_test_metrics_from_P1": floats(frozen_test),
        "rerun_labelled_frozen_test_metrics": floats(ns["zero_shot_test"]),
        "cells": p3,
    }
    save()

    # ---- P4: representative invalid BYOD input (frames without labels) + BYOD outside Colab ----
    import ase.io

    frames = ase.io.read("outputs/mace_materials_sample_dataset.xyz", index=":")
    for a in frames:
        a.calc = None
        a.info.pop("energy", None)
        for key in list(a.arrays):
            if key not in ("numbers", "positions"):
                del a.arrays[key]
    ase.io.write("bad.xyz", frames, format="extxyz")
    try:
        ns["validate_dataset"](ns["load_byod_dataset"](Path("bad.xyz")))
        verdict = {"status": "accepted"}
    except Exception as exc:  # noqa: BLE001
        verdict = {"status": "rejected", "error": f"{type(exc).__name__}: {str(exc)[:300]}"}
    del sys.modules["google.colab"], sys.modules["google"]
    nocolab = run_cell(13, {"USE_BYOD": True}, "Section 4 USE_BYOD=True without google.colab")
    results["probes"]["P4_byod_invalid_and_non_colab"] = {
        "basis": "direct execution, local CPU",
        "unlabelled_xyz": verdict,
        "byod_without_colab": {"status": nocolab["status"], "error": nocolab["error"]},
    }
    save()
print(json.dumps({k: [c.get("status") for c in v.get("cells", [])] for k, v in results["probes"].items()}))
