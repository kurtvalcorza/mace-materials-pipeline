"""P5: BYOD data-contract probes on the notebook's carried module cells (no model load needed).
Executes only the three carried module cells of the notebook, then exercises the notebook's own
split_dataset / validate_dataset / _check_structures (the guard pipe.evaluate and pipe.adapt call first)
on generated EMT-labelled datasets shaped like typical user data.
Usage: python run_probes_byod_contract.py <notebook.ipynb> <results_p5.json>
"""
import json
import sys
from pathlib import Path

nb = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
ns: dict = {"__name__": "__main__"}
for c in nb["cells"]:
    if c["cell_type"] == "code" and "embedded_module" in json.dumps(c.get("metadata", {})):
        exec(compile("".join(c["source"]), "<module>", "exec"), ns)
out = {}


def attempt(fn):
    try:
        return {"status": "ok", "value": fn()}
    except Exception as exc:  # noqa: BLE001
        return {"status": "error", "error": f"{type(exc).__name__}: {str(exc)[:240]}"}


# (a) dataset-size ceiling: the notebook states no dataset maximum, but evaluate/adapt call _check_structures (<=32/call)
for n in (120, 132, 201):
    recs = []
    for part, seed in enumerate((1, 2, 3)):
        for r in ns["generate_sample_dataset"](seed=seed, size=96):
            recs.append({**r, "name": f"s{part}-" + r["name"]})
    recs = recs[:n]
    sp = ns["split_dataset"](recs, val_fraction=0.2, test_fraction=0.25, seed=42)
    out[f"size_{n}"] = {
        "validate_dataset": attempt(lambda: ns["validate_dataset"](recs)["n_records"]),
        "splits": {k: len(v) for k, v in sp.items()},
        "evaluate_guard_on_test (Section 6 pipe.evaluate)": attempt(lambda: len(ns["_check_structures"](sp["test"]))),
        "evaluate_guard_on_val (adapt epoch 0 / Section 8)": attempt(lambda: len(ns["_check_structures"](sp["val"]))),
    }

# (b) one structure per composition (e.g. a relaxed-structures set across stoichiometries), 8 records
base = ns["generate_sample_dataset"](seed=3, size=48)
alloy = [r for r in base if r["composition"] == "Cu16Al16"] if "composition" in base[0] else None
alloy = [r for r in base if sorted(set(r["symbols"])) == ["Al", "Cu"]]
singles = []
for k in range(8):
    r = dict(alloy[k])
    sym = list(r["symbols"])
    # turn k+1 Al atoms into Cu -> a distinct composition per record
    idx = [i for i, s in enumerate(sym) if s == "Al"][: k + 1]
    for i in idx:
        sym[i] = "Cu"
    r["symbols"] = sym
    r["name"] = f"single-{k}"
    r["energy"], r["forces"] = ns["_emt_energy_forces"](ns["to_atoms"](r))
    singles.append(r)
out["one_per_composition_8"] = {
    "validate_dataset": attempt(lambda: ns["validate_dataset"](singles)["n_records"]),
    "split_dataset": attempt(lambda: {k: len(v) for k, v in ns["split_dataset"](singles, seed=42).items()}),
}

# (c) 8 records, 4 compositions x 2 (stated minimum is 8)
pairs = []
for k in range(4):
    for j in range(2):
        r = dict(singles[k])
        r["name"] = f"pair-{k}-{j}"
        pairs.append(r)
sp = attempt(lambda: ns["split_dataset"](pairs, seed=42))
out["four_compositions_x2_8"] = {
    "split_sizes": {k: len(v) for k, v in sp["value"].items()} if sp["status"] == "ok" else sp,
    "section8_val_evaluate_guard": attempt(lambda: len(ns["_check_structures"](sp["value"]["val"]))) if sp["status"] == "ok" else None,
}

# (d) trajectory-like data: 10 near-duplicate frames of ONE composition -> the split puts frames of the
# same trajectory in train and test (the notebook's own advice says split by trajectory)
traj = []
r0 = alloy[0]
import random

rng = random.Random(0)
for f in range(12):
    r = dict(r0)
    r["positions"] = [[x + rng.gauss(0, 0.01) for x in p] for p in r0["positions"]]
    r["name"] = f"traj-A-frame{f:02d}"
    r["energy"], r["forces"] = ns["_emt_energy_forces"](ns["to_atoms"](r))
    traj.append(r)
sp = ns["split_dataset"](traj, seed=42)
out["single_trajectory_12_frames"] = {k: sorted(x["name"] for x in v) for k, v in sp.items()}
import inspect
out["split_dataset_parameters"] = list(inspect.signature(ns["split_dataset"]).parameters)
Path(sys.argv[2]).write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
print(json.dumps({k: (v if not isinstance(v, dict) else list(v)) for k, v in out.items()})[:800])
